# LEC Bundle: colchicine_for_secondary_prevention_after_myocardial_infarction
Run ID: run_20260216_184801_c9254939
Generated: 2026-02-16T18:48:01.902986+00:00

## Contents
- lec_object.json: Main Living Evidence Composite object
- truthcert.json: Verification certificate (Bronze)
- audit_log.json: Detailed verification audit trail
- metaengine_input/output.json: Analysis inputs and results
- discovery_*.json: Search results and candidate lists
- manifest.json: File integrity manifest

## Usage
This bundle contains all artifacts required to reproduce the meta-analysis for this topic.
